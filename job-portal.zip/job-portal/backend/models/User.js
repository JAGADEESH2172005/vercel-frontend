const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    enum: ['jobseeker', 'owner', 'admin'],
    default: 'jobseeker'
  },
  businessName: {
    type: String
  },
  adminCode: {
    type: String
  },
  // New fields for profile editing
  phone: {
    type: String
  },
  address: {
    street: String,
    city: String,
    state: String,
    zipCode: String,
    country: String
  },
  bio: {
    type: String
  },
  profilePicture: {
    type: String
  },
  // Fields for Google authentication
  isGoogleAuth: {
    type: Boolean,
    default: false
  },
  googleId: {
    type: String
  },
  // Fields for OTP authentication
  otp: {
    type: String
  },
  otpExpiry: {
    type: Date
  },
  loginLogs: [{
    loginType: {
      type: String,
      enum: ['email', 'google', 'otp']
    },
    timestamp: {
      type: Date,
      default: Date.now
    },
    success: {
      type: Boolean,
      default: false
    },
    ipAddress: String
  }]
}, {
  timestamps: true
});

// Hash password before saving
userSchema.pre('save', async function(next) {
  // Only hash the password if it's not a Google auth user and password is modified
  if (!this.isModified('password') || this.isGoogleAuth) {
    next();
  }
  
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

// Match user entered password to hashed password in database
userSchema.methods.matchPassword = async function(enteredPassword) {
  // Google auth users don't have passwords to match
  if (this.isGoogleAuth) {
    return true;
  }
  return await bcrypt.compare(enteredPassword, this.password);
};

const User = mongoose.model('User', userSchema);

module.exports = User;
import React from 'react';
import { useNavigate } from 'react-router-dom';

const JobCard = ({ job }) => {
  const navigate = useNavigate();

  const handleApply = () => {
    navigate(`/jobs/${job._id}/apply`);
  };

  const handleSave = () => {
    // Save job functionality
    console.log('Save job', job._id);
  };

  // Format location display
  const getLocationDisplay = () => {
    if (job.location) {
      if (job.location.city && job.location.state && job.location.country) {
        return `${job.location.city}, ${job.location.state}, ${job.location.country}`;
      } else if (job.location.city && job.location.state) {
        return `${job.location.city}, ${job.location.state}`;
      } else if (job.location.city) {
        return job.location.city;
      }
    }
    return 'Location not specified';
  };

  // Format work type display
  const getWorkTypeDisplay = () => {
    switch (job.workType) {
      case 'onsite': return 'On-site';
      case 'remote': return 'Remote';
      case 'hybrid': return 'Hybrid';
      case 'workFromHome': return 'Work from Home';
      default: return 'On-site';
    }
  };

  // Format job type display
  const getJobTypeDisplay = () => {
    switch (job.jobType) {
      case 'fulltime': return 'Full Time';
      case 'parttime': return 'Part Time';
      case 'intern': return 'Intern';
      case 'contract': return 'Contract';
      default: return 'Full Time';
    }
  };

  // Format salary display
  const getSalaryDisplay = () => {
    if (!job.salary) return 'Not specified';
    
    const formattedSalary = job.salary.toLocaleString();
    const salaryType = job.salaryType === 'monthly' ? 'month' : 'year';
    return `₹${formattedSalary}/${salaryType}`;
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-4">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{job.title}</h3>
          <p className="text-gray-600 dark:text-gray-300">{job.ownerId?.name}</p>
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">{getLocationDisplay()}</p>
          
          <div className="flex flex-wrap gap-2 mt-2">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
              {getWorkTypeDisplay()}
            </span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
              {getJobTypeDisplay()}
            </span>
          </div>
        </div>
        <div className="text-right">
          <p className="text-lg font-bold text-blue-600 dark:text-blue-400">{getSalaryDisplay()}</p>
        </div>
      </div>
      
      <p className="text-gray-700 dark:text-gray-300 mt-3 line-clamp-2">
        {job.description}
      </p>
      
      {job.requiredSkills && job.requiredSkills.length > 0 && (
        <div className="mt-3">
          <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Required Skills:</p>
          <div className="flex flex-wrap gap-1 mt-1">
            {job.requiredSkills.slice(0, 5).map((skill, index) => (
              <span key={index} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                {skill}
              </span>
            ))}
            {job.requiredSkills.length > 5 && (
              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                +{job.requiredSkills.length - 5} more
              </span>
            )}
          </div>
        </div>
      )}
      
      <div className="flex justify-between items-center mt-4">
        <div className="flex space-x-2">
          <button
            onClick={handleApply}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium"
          >
            Apply Now
          </button>
          <button
            onClick={handleSave}
            className="border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 px-4 py-2 rounded-md text-sm font-medium"
          >
            Save Job
          </button>
        </div>
        <div className="flex items-center">
          <span className="text-yellow-500 mr-1">★</span>
          <span className="text-gray-600 dark:text-gray-300 text-sm">4.2</span>
        </div>
      </div>
    </div>
  );
};

export default JobCard;
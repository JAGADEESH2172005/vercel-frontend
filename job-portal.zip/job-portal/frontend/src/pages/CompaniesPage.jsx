import React from 'react';
import { useTranslation } from 'react-i18next';

const CompaniesPage = () => {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white sm:text-4xl">
            {t('companies')}
          </h1>
          <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 dark:text-gray-300 sm:mt-4">
            {t('browse_thousands_jobs')}
          </p>
        </div>

        <div className="mt-10">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <div className="text-center py-12">
              <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
              <h3 className="mt-2 text-lg font-medium text-gray-900 dark:text-white">{t('companies')}</h3>
              <p className="mt-1 text-gray-500 dark:text-gray-400">
                {t('no_jobs_found')}
              </p>
              <p className="mt-1 text-gray-500 dark:text-gray-400">
                {t('try_adjusting_search')}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompaniesPage;
import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../utils/api';
import io from 'socket.io-client';
import { useAuth } from './AuthContext';

const NotificationContext = createContext();

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

export const NotificationProvider = ({ children }) => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [socket, setSocket] = useState(null);

  // Initialize socket connection
  useEffect(() => {
    if (user) {
      const newSocket = io('http://localhost:5000');
      setSocket(newSocket);

      // Listen for new notifications
      newSocket.on('new_notification', (notification) => {
        console.log('Received new notification (broadcast):', notification);
        addNotification(notification);
      });

      // Listen for user-specific notifications
      newSocket.on(`notification_${user._id}`, (notification) => {
        console.log(`Received user-specific notification for ${user._id}:`, notification);
        addNotification(notification);
      });

      // Listen for role-based notifications
      newSocket.on(`notification_${user.role}`, (notification) => {
        console.log(`Received role-based notification for ${user.role}:`, notification);
        addNotification(notification);
      });

      console.log(`Setting up socket listeners for user ${user._id} with role ${user.role}`);

      return () => {
        console.log(`Cleaning up socket listeners for user ${user._id}`);
        newSocket.close();
      };
    }
  }, [user]);

  // Fetch notifications when the app loads or user changes
  useEffect(() => {
    if (user) {
      fetchNotifications();
    }
  }, [user]);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const response = await api.get('/notifications');
      const fetchedNotifications = response.data;
      
      setNotifications(fetchedNotifications);
      setUnreadCount(fetchedNotifications.filter(n => !n.read).length);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching notifications:', error);
      // Fallback to mock data if API fails
      const mockNotifications = [
        {
          id: '1',
          type: 'new_job',
          title: 'New Job Posted',
          message: 'A new job "Senior React Developer" has been posted',
          timestamp: new Date(Date.now() - 3600000), // 1 hour ago
          read: false,
          jobId: 'job123'
        },
        {
          id: '2',
          type: 'application_update',
          title: 'Application Status Updated',
          message: 'Your application for "Product Manager" has been reviewed',
          timestamp: new Date(Date.now() - 86400000), // 1 day ago
          read: false,
          applicationId: 'app123'
        },
        {
          id: '3',
          type: 'admin_message',
          title: 'Platform Update',
          message: 'Scheduled maintenance on Sunday at 2 AM',
          timestamp: new Date(Date.now() - 172800000), // 2 days ago
          read: true
        }
      ];
      
      setNotifications(mockNotifications);
      setUnreadCount(mockNotifications.filter(n => !n.read).length);
      setLoading(false);
    }
  };

  // Function to add a new notification (for real-time updates)
  const addNotification = (notification) => {
    // Check if notification already exists to avoid duplicates
    const exists = notifications.some(n => n.id === notification.id);
    if (!exists) {
      console.log('Adding new notification to state:', notification);
      setNotifications(prevNotifications => [notification, ...prevNotifications]);
      setUnreadCount(prevCount => prevCount + 1);
    } else {
      console.log('Notification already exists, skipping:', notification.id);
    }
  };

  const markAsRead = async (id) => {
    try {
      await api.put(`/notifications/${id}/read`);
      setNotifications(notifications.map(notification => 
        notification.id === id ? { ...notification, read: true } : notification
      ));
      setUnreadCount(unreadCount - 1);
    } catch (error) {
      console.error('Error marking notification as read:', error);
      // Update locally even if API fails
      setNotifications(notifications.map(notification => 
        notification.id === id ? { ...notification, read: true } : notification
      ));
      setUnreadCount(unreadCount - 1);
    }
  };

  const markAllAsRead = async () => {
    try {
      await api.put('/notifications/read-all');
      setNotifications(notifications.map(notification => ({ ...notification, read: true })));
      setUnreadCount(0);
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
      // Update locally even if API fails
      setNotifications(notifications.map(notification => ({ ...notification, read: true })));
      setUnreadCount(0);
    }
  };

  const removeNotification = (id) => {
    const notification = notifications.find(n => n.id === id);
    setNotifications(notifications.filter(n => n.id !== id));
    if (!notification.read) {
      setUnreadCount(unreadCount - 1);
    }
  };

  const value = {
    notifications,
    unreadCount,
    loading,
    markAsRead,
    markAllAsRead,
    addNotification,
    removeNotification,
    fetchNotifications,
    socket
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
};